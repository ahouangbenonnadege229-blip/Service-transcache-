TRANSCACHE — PORTAIL WEB INDÉPENDANT

Cette archive contient une application web complète : page client, dépôt de photo, suivi privé,
espace administrateur, base SQLite et stockage privé des photos. Ce portail est indépendant et
n'est pas affilié à Transcash. Il ne vérifie pas automatiquement l'authenticité d'un ticket.

DÉMARRAGE LOCAL
1. Installer Node.js 20 ou plus récent.
2. Décompresser l'archive et ouvrir un terminal dans ce dossier.
3. Exécuter : npm install
4. Copier .env.example en .env.
5. Générer un hash de mot de passe admin :
   node -e "require('bcryptjs').hash('VOTRE_MOT_DE_PASSE_LONG',12).then(console.log)"
6. Coller le hash dans ADMIN_PASSWORD_HASH; choisir ADMIN_USERNAME et SESSION_SECRET.
7. Exécuter : npm start
8. Ouvrir http://localhost:3000 ; admin : http://localhost:3000/admin.html

PUBLICATION
Déployer comme application Node.js (pas comme site statique), commande : npm start.
Configurer NODE_ENV=production, SESSION_SECRET, ADMIN_USERNAME, ADMIN_PASSWORD_HASH et DATA_DIR.
Attacher un disque persistant à DATA_DIR. Sans disque persistant, les données et photos peuvent
être perdues lors des redémarrages/redéploiements. Activer HTTPS. Ne jamais publier le fichier .env.

SÉCURITÉ / LIMITES
Les photos sont hors du dossier public et protégées par la connexion admin. Le suivi client exige
la référence et un code privé remis une seule fois après le dépôt. Le client doit conserver ce code.
La vérification est manuelle : aucun accès à un système émetteur, OCR ou contrôle automatique n'est
intégré. Ne jamais demander de PIN, mot de passe ou code de recharge utilisable. Avant diffusion
publique importante, ajouter CAPTCHA/anti-bot, sauvegardes, surveillance et politique de conservation.
